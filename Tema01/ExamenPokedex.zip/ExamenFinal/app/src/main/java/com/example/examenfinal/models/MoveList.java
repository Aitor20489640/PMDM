package com.example.examenfinal.models;

import java.util.ArrayList;

public class MoveList {
    private ArrayList<MoveListItem> results;
    public ArrayList<MoveListItem> getResults() {
        return results;
    }

}
