package com.example.examenfinal.models;

public class ItemListDetails {
    private String name;

    public String getName() {
        return name;
    }
}
