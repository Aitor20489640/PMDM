package com.example.examenfinal.models;

import java.util.ArrayList;

public class ItemList {
    private ArrayList<ItemListDetails> results;

    public ArrayList<ItemListDetails> getResults() {
        return results;
    }
}
