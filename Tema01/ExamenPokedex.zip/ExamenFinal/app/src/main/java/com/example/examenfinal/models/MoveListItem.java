package com.example.examenfinal.models;

public class MoveListItem {
    private String name;

    public String getName() {
        return name;
    }
}
